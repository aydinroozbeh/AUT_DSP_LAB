clear; close; clc;
n=100;
w=2*pi
array=0:1:n-1;
res=sin(w.*array);
plot(res)