function res = singen(w,n)

array=0:1:n-1;
array=array./n;
res=sin(w.*array);